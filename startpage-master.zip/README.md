#Startpage
This is a very simple startpage that I created for personal use.
Feel free to use it and to submit improvements.

The search form will redirect to a duckduckgo search.

You can check out a live version over at [startpage.salloum.ch](http://startpage.salloum.ch/)

###Screenshot
![screenshot](img/screenshot.png)